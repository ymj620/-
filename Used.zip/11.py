import cv2
from picamera.array import PiRGBArray
from picamera import PiCamera
import numpy as np
import os
from PIL import Image
import RPi.GPIO as GPIO
import Tkinter as TK
from Tkinter import *
import tkMessageBox
from datetime import datetime
import time
from PIL import Image
import threading

pin = 18
GPIO.setmode(GPIO.BCM)
GPIO.setup(pin,GPIO.OUT)
p=GPIO.PWM(pin,50)
p.start(0)
cnt=0

#t1 = threading.Thread(target=capturePic)
#t2 = threading.Thread(target=trainSet)
#XX=t1.start()
#YY=t2.start()


now = datetime.now()
top = TK.Tk()
var = IntVar()
#var0  = StringVar()
#label0 = Label(top, textvariable=var,relief = RAISED)

capture = 30
servo0 = 0

def helloCallBack():
    tkMessageBox.showinfo("Error","NotExsist, sorry.")

    
def donothing():
    filewin = Toplevel(top)
    button = Button(filewin,text="Do nothing button")
    button.pack()
    
def setting0():
    selection = "You need to select options" + str(var.get())
    label.config(text = selection)
    R1 = Radiobutton(top,text="Option 1", variable=var,value=1,command=sel)
    R2 = Radiobutton(top,text="Option 2", variable=var,value=2,command=sel)
    R3 = Radiobutton(top,text="Option 3", variable=var,value=3,command=sel)
    R1.pack( anchor = W )
    R2.pack( anchor = W )
    R3.pack( anchor = W )

    label = Label(top)
    label.pack()

def screeenServo():
    pin = 18
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(pin,GPIO.OUT)
    p=GPIO.PWM(pin,50)
    p.start(0)
    cnt=0

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read('trainer/trainer.yml')
    cascadePath = "haarcascades/haarcascade_frontalface_default.xml"
    eyeCascade = cv2.CascadeClassifier("haarcascades/haarcascade_eye.xml")
    faceCascade = cv2.CascadeClassifier(cascadePath);
    font = cv2.FONT_HERSHEY_SIMPLEX

    time.sleep(0.1)

    id = 0
    names = ['none', 'JH.L', 'Subin.L', 'SI.L', 'HJ.L']

    cam = PiCamera()
    cam.resolution = (640, 480)
    cam.framerate = 32
    rawCapture = PiRGBArray(cam, size=(640, 480))
    minW = 0.1*640
    minH = 0.1*480

    detect=0
    servo=0
    training=0
    capturing=0

    for frame in cam.capture_continuous(rawCapture, format="bgr" , use_video_port=True):

        ret = frame.array
        img = frame.array
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        gray = cv2.equalizeHist(gray)
        
        vis = img
        
        if detect == 0 :
            faces = faceCascade.detectMultiScale(gray,
                scaleFactor=1.2, minNeighbors=5,minSize=(20,20))
            for (x,y,w,h) in faces:
                cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
                roi_gray = gray[y:y+h, x:x+w]
                roi_color = img[y:y+h, x:x+w]
                detect=1

                eyes = eyeCascade.detectMultiScale(roi_gray, scaleFactor= 1.5, minNeighbors=10, minSize=(5, 5))
                for (ex,ey,ew,eh) in eyes:
                    cv2.rectangle(roi_color, (ex,ey), (ex + ew, ey + eh), (0, 255, 0), 2)

        else :
            faces = faceCascade.detectMultiScale( 
                gray,
                scaleFactor = 1.2,
                minNeighbors = 5,
                minSize = (int(minW), int(minH)),
               )

            for(x,y,w,h) in faces:
                cv2.rectangle(img, (x,y), (x+w,y+h), (0,255,0), 2)
                id, confidence = recognizer.predict(gray[y:y+h,x:x+w])
                # Check if confidence is less them 100 ==> "0" is perfect match
                if (confidence < 60):
                    id = names[id]
                    confidence = "  {0}%".format(round(130 - confidence))
                    servo=1
                else:
                    id = "unknown"
                    confidence = "  {0}%".format(round(130 - confidence))
            
                cv2.putText(img, str(id), (x+5,y-5), font, 1, (255,255,255), 2)
                cv2.putText(img, str(confidence), (x+5,y+h-5), font, 1, (255,255,0), 1)  
        
        cv2.imshow('image', vis)
            
        key = cv2.waitKey(1) & 0xFF
        rawCapture.truncate(0)
    # clear the stream in preparation for the next frame

    # if the 'q' key was pressed, break from the loop
        if training == 1:
            break
        
        if capturing == 1:
            break

        if key == ord("q"):
            break


        if servo == 1 :
            p.ChangeDutyCycle(2)
            time.sleep(1)
            print "angle : Open "
            time.sleep(5)
            p.start(0)
            time.sleep(1)
            p.ChangeDutyCycle(50)
            time.sleep(1)
            print "angle : Close "
            p.stop()

            GPIO.cleanup()
            servo=0
            time.sleep(1)

def capturePic():

    capturing=1

    camera = PiCamera()

    camera.resolution = (640, 480)
    camera.framerate = 32
    rawCapture = PiRGBArray(camera, size=(640, 480))

    face_detector = cv2.CascadeClassifier('haarcascades/haarcascade_frontalface_default.xml')

    # For each person, enter one numeric face id

    face_id = input('\n enter user id end press <return> ==>  ')
    print("\n [INFO] Initializing face capture. Look the camera and wait ...")

    # Initialize individual sampling face count
    count = 0
    pictures = 30


    for frame in camera.capture_continuous(rawCapture, format="bgr" , use_video_port=True):
        ret = frame.array
        img = frame.array
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        gray = cv2.equalizeHist(gray)
        
        faces = face_detector.detectMultiScale(gray, 1.3, 5)
        
        vis = img
        
        for (x,y,w,h) in faces:
            cv2.rectangle(img, (x,y), (x+w,y+h), (255,0,0), 2)     
            count += 1

            vis = img.copy()
            cv2.imwrite("dataset/User." + str(face_id) + '.' + str(count) + ".jpg", gray[y:y+h,x:x+w])
        cv2.imshow('image', vis)
        
        if count >= pictures: # Take 30 face sample and stop video
             break
            
        key = cv2.waitKey(1) & 0xFF
        rawCapture.truncate(0)
    # clear the stream in preparation for the next frame

    # if the 'q' key was pressed, break from the loop

        if key == ord("q"):
            break


    # Do a bit of cleanup
    print("\n [INFO] Exiting Program and cleanup stuff")
    capturing=0

def getImagesAndLabels(path):
        imagePaths = [os.path.join(path,f) for f in os.listdir(path)]     
        faceSamples=[]
        ids = []
        for imagePath in imagePaths:
            PIL_img = Image.open(imagePath).convert('L') # convert it to grayscale
            img_numpy = np.array(PIL_img,'uint8')
            id = int(os.path.split(imagePath)[-1].split(".")[1])
            faces = detector.detectMultiScale(img_numpy)
            for (x,y,w,h) in faces:
                faceSamples.append(img_numpy[y:y+h,x:x+w])
                ids.append(id)
        return faceSamples,ids
    
def trainSet():
    training=1
    # Path for face image database
    path = 'dataset'
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    detector = cv2.CascadeClassifier("haarcascades/haarcascade_frontalface_default.xml");
    # function to get the images and label data
    
    print ("\n [INFO] Training faces. It will take a few seconds. Wait ...")
    faces,ids = getImagesAndLabels(path)
    recognizer.train(faces, np.array(ids))
    # Save the model into trainer/trainer.yml
    recognizer.write('trainer/trainer.yml') # recognizer.save() worked on Mac, but not on Pi
    # Print the numer of faces trained and end program
    print("\n [INFO] {0} faces trained. Exiting Program".format(len(np.unique(ids))))
    training=0
    

    
def exitAndCleanup():
    GPIO.cleanup()
    top.quit();
    
    #filename = PhotoImage(file = "sunshine.gif")


C = TK.Canvas(top,bg="white",height=480,width=800)

#image = C.create_image(50,50,anchor=NE,image=filename)
oval = C.create_polygon(0,0,640,0,640,480,0,480, fill="red")


B1 = TK.Button(top,text = "History", command = screeenServo)#openServo)
B2 = TK.Button(top,text = "Capture", command = capturePic)#XX)#closeServo)
B3 = TK.Button(top,text = "Training", command = trainSet)#YY)
B4 = TK.Button(top,text = "Setting", command = setting0)
B5 = TK.Button(top,text = "Exit", command = exitAndCleanup)

B1.pack()
B1.place(x=640,y=0,height=120,width=160)
B2.pack()
B2.place(x=640,y=120,height=120,width=160)
B3.pack()
B3.place(x=640,y=240,height=120,width=160)
B4.pack()
B4.place(x=640,y=360,height=120,width=80)
B5.pack()
B5.place(x=720,y=360,height=120,width=80)
C.pack()

top.attributes("-fullscreen",True)
top.title("Recognizer")
top.resizable(False,False)
top.bind("<F11>",lambda event : top.attributes("-fullscreen" , not top.attributes("-fullscreen")))
top.bind("<Escape>",lambda event : top.attributes("-fullscreen",False))

#menubar = Menu(top)
#fm = Menu(menubar,tearoff=0)
#fm.add_command(label="New",command=donothing)

#fm.add_separator()

#fm.add_command(label="Exit",command=top.quit)
#menubar.add_cascade(label="File",menu=fm)

#em = Menu(menubar,tearoff=0)
#em.add_command(label="Undo", command=donothing)
#em.add_command(label="Redo", command=donothing)
#em.add_separator()
#em.add_command(label="Cut", command=donothing)

#menubar.add_cascade(label="Edit",menu=em)
#hm=Menu(menubar,tearoff=0)
#hm.add_command(label="Help Index", command=donothing)
#menubar.add_cascade(label="Help",menu=hm)

#top.config(menu=menubar)

#var0.set("Now")
#label0.pack
#label0.place(x=50,y=450)
print(now)
top.mainloop()
