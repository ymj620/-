# import the necessary packages
from picamera.array import PiRGBArray
from picamera import PiCamera
import numpy as np
import time
import cv2

camera = PiCamera()

camera.resolution = (640, 480)
camera.framerate = 32
rawCapture = PiRGBArray(camera, size=(640, 480))

faceCascade = cv2.CascadeClassifier("haarcascades/haarcascade_frontalface_alt.xml")
eyeCascade = cv2.CascadeClassifier("haarcascades/haarcascade_eye.xml")
smileCascade = cv2.CascadeClassifier("haarcascades/haarcascade_smile.xml")

# allow the camera to warmup

time.sleep(0.1)

# capture frames from the camera

for frame in camera.capture_continuous(rawCapture, format="bgr" , use_video_port=True):

# grab the raw NumPy array representing the image, then initialize the timestamp
# and occupied/unoccupied text

    img  = frame.array
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)

    faces = faceCascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5,minSize=(20,20))
    for (x,y,w,h) in faces:
        cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
        roi_gray = gray[y:y+h, x:x+w]
        roi_color = img[y:y+h, x:x+w]

        eyes = eyeCascade.detectMultiScale(roi_gray, scaleFactor= 1.5, minNeighbors=10, minSize=(5, 5))
        for (ex,ey,ew,eh) in eyes:
            cv2.rectangle(roi_color, (ex,ey), (ex + ew, ey + eh), (0, 255, 0), 2)

        smile = smileCascade.detectMultiScale(roi_gray, scaleFactor= 1.5, minNeighbors=15, minSize=(25,25))
        for (sx,sy,sw,sh) in smile:
            cv2.rectangle(roi_color, (sx,sy), (sx + sw, sy + sh), (0, 255, 0), 2)


    vis = img.copy()

# show the result


    cv2.imshow("video", vis)
    key = cv2.waitKey(1) & 0xFF
    rawCapture.truncate(0)
# clear the stream in preparation for the next frame

# if the 'q' key was pressed, break from the loop

    if key == ord("q"):
        break

