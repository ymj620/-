# -*- coding: utf-8 -*-
import Tkinter as TK
from Tkinter import *
import tkMessageBox
from datetime import datetime
import time
import RPi.GPIO as GPIO

pin = 18
GPIO.setmode(GPIO.BCM)
GPIO.setup(pin,GPIO.OUT)
p=GPIO.PWM(pin,50)
p.start(0)
cnt=0


now = datetime.now()
root = TK.Tk()
var = IntVar()
#var0  = StringVar()
#label0 = Label(top, textvariable=var,relief = RAISED)
capture = 30
servo0 = 0

class MyFrame(Frame):
    def __init__(self,master):
        img = PhotoImage(file='a.png')
        lbl = Label(image=img)
        lbl.image = img
        lbl.place(x=0,y=0)
        
def main():
    root = Tk()
    root.title('Recognition')
    root.geometry('500x400+10+10')
    myframe=MyFrame(root)
    root.mainloop()
    
if __name__ == '__main__' :
    main()

def timer():
    print(now)

def helloCallBack():
    tkMessageBox.showinfo("Hello Python","Hello World")

    
def donothing():
    filewin = Toplevel(top)
    button = Button(filewin,text="Do nothing button")
    button.pack()
    
def setting0():
    selection = "You need to select options" + str(var.get())
    label.config(text = selection)
    R1 = Radiobutton(top,text="Option 1", variable=var,value=1,command=sel)
    R2 = Radiobutton(top,text="Option 2", variable=var,value=2,command=sel)
    R3 = Radiobutton(top,text="Option 3", variable=var,value=3,command=sel)
    R1.pack( anchor = W )
    R2.pack( anchor = W )
    R3.pack( anchor = W )

    label = Label(top)
    label.pack()
    
def openServo():
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(pin,GPIO.OUT)
    p=GPIO.PWM(pin,50)
    p.start(0)
    global servo0
    time.sleep(1)
    p.ChangeDutyCycle(45)
    time.sleep(3)
    print "angle : O "
#    time.sleep(5)
#    p.stop()
    servo0=0
    p.stop()
    GPIO.cleanup()
    
def closeServo():
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(pin,GPIO.OUT)
    p=GPIO.PWM(pin,50)
    p.start(0)
    global servo0
    time.sleep(1)
    p.ChangeDutyCycle(0)
    time.sleep(3)
    print "angle : C "
    servo0=1
    p.stop()
    GPIO.cleanup()
    
def exitAndCleanup():
    GPIO.cleanup()
    top.quit();

def showImage():
    #filename = PhotoImage(file = "sunshine.gif")
    C = TK.Canvas(top,bg="white",height=480,width=800)
    #image = C.create_image(50,50,anchor=NE,image=filename)
    oval = C.create_polygon(0,0,640,0,640,480,0,480, fill="red")

def Buttons():
    B1 = TK.Button(top,text = "History", command = helloCallBack)#openServo)
    B2 = TK.Button(top,text = "Capture", command = helloCallBack)#closeServo)
    B3 = TK.Button(top,text = "Training", command = helloCallBack)
    B4 = TK.Button(top,text = "Setting", command = setting0)
    B5 = TK.Button(top,text = "Exit", command = exitAndCleanup)

    B1.pack()
    B1.place(x=640,y=0,height=120,width=160)
    B2.pack()
    B2.place(x=640,y=120,height=120,width=160)
    B3.pack()
    B3.place(x=640,y=240,height=120,width=160)
    B4.pack()
    B4.place(x=640,y=360,height=120,width=80)
    B5.pack()
    B5.place(x=720,y=360,height=120,width=80)
    C.pack()

    top.attributes("-fullscreen",True)
    top.title("Recognizer")
    top.resizable(False,False)
    top.bind("<F11>",lambda event : top.attributes("-fullscreen" , not top.attributes("-fullscreen")))
    top.bind("<Escape>",lambda event : top.attributes("-fullscreen",False))

    top.mainloop()