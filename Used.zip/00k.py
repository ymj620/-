# -*- coding: utf-8 -*-
from Tkinter import *
import Tkinter
from datetime import datetime
import time
import tkMessageBox
import RPi.GPIO as GPIO




now = datetime.now()

class MyFrame(Frame):
    def __init__(self, master):
        img = PhotoImage(file='a.png')
        lbl = Label(image=img)
        lbl.image = img  # 레퍼런스 추가
        lbl.place(x=0, y=0)
        
def helloCallBack():
    tkMessageBox.showinfo("Hello Python","Hello World")

    
def donothing():
    filewin = Toplevel(top)
    button = Button(filewin,text="Do nothing button")
    button.pack()
        
def imgButtons():
    top=Toplevel()
    #filename = PhotoImage(file = "sunshine.gif")
    C = Tkinter.Canvas(top,bg="white",height=480,width=800)
    #image = C.create_image(50,50,anchor=NE,image=filename)
    oval = C.create_polygon(0,0,640,0,640,480,0,480, fill="red")
    
    
    B1 = Button(top,text = "History", command = helloCallBack)#openServo)
    B2 = Button(top,text = "Capture", command = donothing)#closeServo)
    B3 = Button(top,text = "Training", command = helloCallBack)
    B4 = Button(top,text = "Setting", command = setting0)
    B5 = Button(top,text = "Exit", command = exitAndCleanup)

    B1.pack()
    B1.place(x=640,y=0,height=120,width=160)
    B2.pack()
    B2.place(x=640,y=120,height=120,width=160)
    B3.pack()
    B3.place(x=640,y=240,height=120,width=160)
    B4.pack()
    B4.place(x=640,y=360,height=120,width=80)
    B5.pack()
    B5.place(x=720,y=360,height=120,width=80)

    C.pack()

    top.attributes("-fullscreen",True)
    top.title("Recognizer")
    top.resizable(False,False)
    top.bind("<F11>",lambda event : top.attributes("-fullscreen" , not top.attributes("-fullscreen")))
    top.bind("<Escape>",lambda event : top.attributes("-fullscreen",False))
    top.mainloop()

 
def main0():
    root = Tk()
    root.title('이미지 보기')
    root.geometry('500x400+10+10')
    myframe = MyFrame(root)
    
def main():
    root = Tk()
    root.title('이미지 보기')
    root.geometry('500x400+10+10')
    myframe = MyFrame(root)
    root.mainloop()
    
def setting0():
    selection = "You need to select options" + str(var.get())
    label.config(text = selection)
    R1 = Radiobutton(top,text="Option 1", variable=var,value=1,command=sel)
    R2 = Radiobutton(top,text="Option 2", variable=var,value=2,command=sel)
    R3 = Radiobutton(top,text="Option 3", variable=var,value=3,command=sel)
    R1.pack( anchor = W )
    R2.pack( anchor = W )
    R3.pack( anchor = W )

    label = Label(top)
    label.pack()
    
def exitAndCleanup():
    #GPIO.cleanup()
    top.quit();


if __name__ == '__main__':
    
    main0()
    main()
    imgButtons()